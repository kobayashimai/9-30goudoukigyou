﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class timescript : MonoBehaviour {

	private float time = 60;
    public AudioClip main;
    private AudioSource audioSource;
    public int startingPitch = 1;
    public int timeToDecrease = 1;
    AudioSource audio;



    void Start () {

		//初期値60を表示
		//float型からint型へCastし、String型に変換して表示
		GetComponent<Text>().text = ((int)time).ToString();

        //BGMスタート
        audioSource = gameObject.GetComponent<AudioSource>();
        audioSource.clip = main;
        audioSource.Play();

    }

    void Update (){

        if (time <= 15)
        {
            //BGMを急かす
            audio = GetComponent<AudioSource>();
            audio.pitch = startingPitch;
            audio.pitch -= Time.deltaTime * startingPitch / timeToDecrease;
        }

        //1秒に1ずつ減らしていく
        time -= Time.deltaTime;
		//マイナスは表示しない
		if (time < 0) time = 0;
		GetComponent<Text> ().text = ((int)time).ToString ();

        bool isDone= false;

        if (isDone == false) { 
		    if (time == 0) {    
                   
                isDone = true;
                Application.LoadLevel ("GameOver");
 
            }
	    }
    }
}