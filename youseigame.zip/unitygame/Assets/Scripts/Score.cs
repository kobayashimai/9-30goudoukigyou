﻿using UnityEngine; 
using System.Collections; 
using UnityEngine.UI; 

 public class Score : MonoBehaviour { 


public Text scoreText; //Text用変数 
public int score = 0; //スコア計算用変数 
//private static bool created = false;
private Transform playerTrans;
public AudioClip get;
public AudioClip get2;
public AudioClip down;
private AudioSource audioSource;

    public static Score Instance
    { 
 		get; private set; 
 	}



    void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }






    void Start (){

        scoreText.text = "Score: 0"; //初期スコアを代入して画面に表示 

    }


void CountDown() {

        scoreText.text = "Score: " + score.ToString();
		} 

void Update (){
         
    }

    public void scoreup()
    {
        score += 10;
        scoreText.text = "Score: " + score.ToString();
        audioSource = gameObject.GetComponent<AudioSource>();
        audioSource.PlayOneShot(get); //音を重ねない時は audioSource.clip = get;
        audioSource.Play();




    }

    public void scoreup2()
    {
        score += 50;
        scoreText.text = "Score: " + score.ToString();
        audioSource = gameObject.GetComponent<AudioSource>();      
        audioSource.PlayOneShot(get2); //音を重ねない時は audioSource.clip = get2;
        audioSource.Play();

        

    }

    public void scoredown()
    {
        score -= 10;
        scoreText.text = "Score: " + score.ToString();
        audioSource = gameObject.GetComponent<AudioSource>();
        audioSource.PlayOneShot(down); //音を重ねない時は audioSource.clip = down;
        audioSource.Play();
    }





}
	


