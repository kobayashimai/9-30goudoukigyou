﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Life : MonoBehaviour
{


    public Text lifeText; //Text用変数 
    public int life = 3; //スコア計算用変数 

    private Transform playerTrans;
    public AudioClip damage;
    public AudioClip gameover;
    private AudioSource audioSource;

    void Start()
    {

        lifeText.text = "残りライフ: 3"; //初期スコアを代入して画面に表示 
    }

    void CountDown()
    {
        lifeText.text = "残りライフ: " + life.ToString();
    }

    void Update()
    {
        //ライフが0になったらゲームオーバー画面へ
        if (life == 0)
        {
            audioSource = gameObject.GetComponent<AudioSource>();
            audioSource.clip = gameover;
            audioSource.Play();

            Application.LoadLevel("GameOver");

        }

    }


    public void lifedown()
    {
        audioSource = gameObject.GetComponent<AudioSource>();
        audioSource.clip = damage;
        audioSource.Play();

        life -= 1; //Lifeに加算 
        //更新して表示 
        lifeText.text = "残りライフ: " + life.ToString();
    }






}
	



