﻿using UnityEngine;
using System.Collections;

public class enemy3 : MonoBehaviour
{

    public int Speed = 5;
    int a;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    //ナナメに動く
    void Update()
    {

        Vector3 scale = transform.localScale;

        a = (int)(Time.time % 2);
        if (a == 0)
        {
            transform.Translate(new Vector3(2, 2, 0) * Time.deltaTime * Speed);
            scale.x = -1;
            transform.localScale = scale;
        }
        else
        {
            transform.Translate(new Vector3(-2, -2, 0) * Time.deltaTime * Speed);
            scale.x = 1;
            transform.localScale = scale;
        }
    }
}