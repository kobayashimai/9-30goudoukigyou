﻿using UnityEngine;
using System.Collections;

public class retryscript : MonoBehaviour {

	public void ClickTest () {
		//Debug.Log ("Clicked.");
		Application.LoadLevel ("Start");
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetKey(KeyCode.Tab))
        {
            Application.LoadLevel("Start");
        }

    }
}
