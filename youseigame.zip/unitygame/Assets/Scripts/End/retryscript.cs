﻿using UnityEngine;
using System.Collections;

public class retryscript : MonoBehaviour {

    // ボタンクリックでスタート画面に戻る
	public void ClickTest () {
		//Debug.Log ("Clicked.");
		Application.LoadLevel ("Start");
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
    // Tabキーでスタート画面に戻る
	void Update () {

        if (Input.GetKey(KeyCode.Tab))
        {
            Application.LoadLevel("Start");
        }

    }
}
