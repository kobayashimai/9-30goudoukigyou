﻿using UnityEngine;
using System.Collections;

public class hardstartscript : MonoBehaviour {

	public void ClickTest () {
		//Debug.Log ("Clicked.");
		Application.LoadLevel ("HMain");
	}

	// Use this for initialization
	void Start () {

    }

        // Update is called once per frame
        void Update () {


        }
    }
