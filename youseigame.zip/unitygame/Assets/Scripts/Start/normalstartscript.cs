﻿using UnityEngine;
using System.Collections;

public class normalstartscript : MonoBehaviour {

	public void ClickTest () {
		//Debug.Log ("Clicked.");
		Application.LoadLevel ("Main");
	}

	// Use this for initialization
	void Start () {

    }

        // Update is called once per frame
        void Update () {


        }
    }
